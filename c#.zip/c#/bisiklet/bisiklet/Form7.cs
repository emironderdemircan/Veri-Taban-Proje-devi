﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bisiklet
{
    public partial class Form7 : Form
    {

        private string connectionString = "server=localHost; port=5432; Database=bisiklet; user ID=postgres; password=123";
        private Npgsql.NpgsqlConnection conn;
        private string sql;
        private Npgsql.NpgsqlCommand cmd;
        private Npgsql.NpgsqlDataReader dr;
        public Form7()
        {
            InitializeComponent();
            conn = new Npgsql.NpgsqlConnection(connectionString);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            sql = @"SELECT * FROM st_selectyetkili(:_kadi, :_ksifre)";
            cmd = new Npgsql.NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("_kadi", textBox1.Text);
            cmd.Parameters.AddWithValue("_ksifre", textBox2.Text);
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                if (dr.FieldCount > 0)
                {
                    this.Hide();
                    Form1 kullaniciPanel  = new Form1();
                    kullaniciPanel.Show();
                }
                else
                {
                    MessageBox.Show("Hatalı Giriş");
                }
            }
            else
            {
                MessageBox.Show("Bilgiler Hatalı");
            }
            conn.Close();
        }
    }
}
