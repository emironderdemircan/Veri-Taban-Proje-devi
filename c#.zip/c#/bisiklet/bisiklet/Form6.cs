﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bisiklet
{
    public partial class Form6 : Form
    {

        private string connectionString = "server=localHost; port=5432; Database=bisiklet; user ID=postgres; password=123";
        private Npgsql.NpgsqlConnection conn;
        private string sql;
        private Npgsql.NpgsqlCommand cmd;
        private DataTable dt;
        private int rowIndex = -1;

        public Form6()
        {
            InitializeComponent();
            conn = new Npgsql.NpgsqlConnection(connectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                sql = @"select * from st_selectsiparis()";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                conn.Close();
                kullaniciData.DataSource = null;
                kullaniciData.DataSource = dt;
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 A = new Form1();
            A.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (rowIndex < 0)
            {
                MessageBox.Show("Lütfen kullanıcı seçiniz");
                return;
            }
            try
            {
                conn.Open();
                sql = @"select * from update_bisiklet(:_urunId ,:_urunAdi,:_firmaId, :_satisFiyati, :_bisikletTürü)";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_urunId", int.Parse(kullaniciData.Rows[rowIndex].Cells["k_urunId"].Value.ToString()));
                cmd.Parameters.AddWithValue("_urunAdi", textBox1.Text);
                cmd.Parameters.AddWithValue("_firmaId", int.Parse(textBox2.Text));
                cmd.Parameters.AddWithValue("_satisFiyati", int.Parse(textBox3.Text));
                cmd.Parameters.AddWithValue("_bisikletTürü", textBox4.Text);
                if ((int)cmd.ExecuteScalar() == 1)
                {
                    sql = @"select * from st_selectsiparis()";
                    cmd = new Npgsql.NpgsqlCommand(sql, conn);
                    dt = new DataTable();
                    dt.Load(cmd.ExecuteReader());
                    conn.Close();
                    kullaniciData.DataSource = null;
                    kullaniciData.DataSource = dt;
                    MessageBox.Show("Guncelleme işlemi başarılı");
                    rowIndex = -1;

                }
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Update fail. Error: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (rowIndex < 0)
            {
                MessageBox.Show("Lütfen kullanıcı seçiniz");
                return;
            }
            try
            {
                conn.Open();
                sql = @"select * from Bisiklet_delete(:k_urunId)";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("k_urunId", int.Parse(kullaniciData.Rows[rowIndex].Cells["k_urunId"].Value.ToString()));
                if ((int)cmd.ExecuteScalar() == 1)
                {
                    sql = @"select * from st_selectsiparis()";
                    cmd = new Npgsql.NpgsqlCommand(sql, conn);
                    dt = new DataTable();
                    dt.Load(cmd.ExecuteReader());
                    conn.Close();
                    kullaniciData.DataSource = null;
                    kullaniciData.DataSource = dt;
                    MessageBox.Show("Silme işlemi başarılı");
                    rowIndex = -1;

                }
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Deleted fail. Error: " + ex.Message);
            }
        }

        private void kullaniciData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                rowIndex = e.RowIndex;
                textBox1.Text = kullaniciData.Rows[e.RowIndex].Cells["k_urunAdi"].Value.ToString();
                textBox2.Text = kullaniciData.Rows[e.RowIndex].Cells["k_firmaId"].Value.ToString();
                textBox3.Text = kullaniciData.Rows[e.RowIndex].Cells["k_satisFiyati"].Value.ToString();
                textBox4.Text = kullaniciData.Rows[e.RowIndex].Cells["k_bisikletTürü"].Value.ToString();
            }
        }
    }
}
