﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bisiklet
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 UyeGiris = new Form7();
            UyeGiris.Show();
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form9 UyeKayit = new Form9();
            UyeKayit.Show();
        }
    }
}
