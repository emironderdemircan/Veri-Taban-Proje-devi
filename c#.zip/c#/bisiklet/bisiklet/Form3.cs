﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bisiklet
{
    public partial class Form3 : Form
    {

        private string connectionString = "server=localHost; port=5432; Database=bisiklet; user ID=postgres; password=123";
        private Npgsql.NpgsqlConnection conn;
        private string sql;
        private Npgsql.NpgsqlCommand cmd;
        private DataTable dt;




        public Form3()
        {
            InitializeComponent();
            conn = new Npgsql.NpgsqlConnection(connectionString);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                sql = @"select * from st_select()";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                conn.Close();
                kullaniciData.DataSource = null;
                kullaniciData.DataSource = dt;
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 A = new Form1();
            A.Show();
        }
    }
}
