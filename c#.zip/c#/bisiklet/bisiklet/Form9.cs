﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bisiklet
{
    public partial class Form9 : Form
    {

        private string connectionString = "server=localHost; port=5432; Database=bisiklet; user ID=postgres; password=123";
        private Npgsql.NpgsqlConnection conn;
        private string sql;
        private Npgsql.NpgsqlCommand cmd;
        private DataTable dt;
        private int rowIndex = -1;
        public Form9()
        {
            InitializeComponent();
            conn = new Npgsql.NpgsqlConnection(connectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int result = 0;
                conn.Open();
                sql = @"select * from insert_yetkili(:_kullaniciId, :_kullaniciAdi, :_kullaniciSifre, :_evTel, :_isTel, :_cepTel, :_kullaniciAdres)";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_kullaniciId", int.Parse(textBox1.Text));
                cmd.Parameters.AddWithValue("_kullaniciAdi", textBox2.Text);
                cmd.Parameters.AddWithValue("_kullaniciSifre", textBox3.Text);
                cmd.Parameters.AddWithValue("_evTel", int.Parse(textBox4.Text));
                cmd.Parameters.AddWithValue("_isTel", int.Parse(textBox5.Text));
                cmd.Parameters.AddWithValue("_cepTel", int.Parse(textBox6.Text));
                cmd.Parameters.AddWithValue("_kullaniciAdres", textBox7.Text);
                result = (int)cmd.ExecuteScalar();
                conn.Close();

                if (result == 1)
                {
                    MessageBox.Show("Kayıt başarılı şekilde kaydedildi.");
                }
                else
                {
                    MessageBox.Show("Kayıt işlemi sırasında hata alındı.");
                }
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error" + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 B = new Form8();
            B.Show();
        }
    }
}
