﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bisiklet
{
    public partial class Form5 : Form
    {
        private string connectionString = "server=localHost; port=5432; Database=bisiklet; user ID=postgres; password=123";
        private Npgsql.NpgsqlConnection conn;
        private string sql;
        private Npgsql.NpgsqlCommand cmd;
        private DataTable dt;

        private void Form5_Load(object sender, EventArgs e)
        {
            Select();
        }

        public Form5()
        {
            InitializeComponent();
            conn = new Npgsql.NpgsqlConnection(connectionString);
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int result = 0;
                conn.Open();
                sql = @"select * from insert_bisiklet(:_urunAdi, :_firmaId, :_satisFiyati, :_bisikletTürü)";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_urunAdi", textBox1.Text);
                cmd.Parameters.AddWithValue("_firmaId", int.Parse(textBox2.Text));
                cmd.Parameters.AddWithValue("_satisFiyati", int.Parse(textBox3.Text));
                cmd.Parameters.AddWithValue("_bisikletTürü", textBox4.Text);
                result = (int)cmd.ExecuteScalar();
                conn.Close();

                if (result == 1)
                {                  
                    MessageBox.Show("Siparis başarılı şekilde kaydedildi.");
                }
                else
                {
                    MessageBox.Show("Siparis işlemi sırasında hata alındı.");
                }
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error" + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 A = new Form1();
            A.Show();
        }
    }
}
