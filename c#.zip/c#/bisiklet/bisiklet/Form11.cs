﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bisiklet
{
    public partial class Form11 : Form
    {
        private string connectionString = "server=localHost; port=5432; Database=bisiklet; user ID=postgres; password=123";
        private Npgsql.NpgsqlConnection conn;
        private string sql;
        private Npgsql.NpgsqlCommand cmd;
        private DataTable dt;
        private int rowIndex = -1;
        public Form11()
        {
            InitializeComponent();
            conn = new Npgsql.NpgsqlConnection(connectionString);
        }

        void Select()
        {
            try
            {
                conn.Open();
                sql = @"select * from st_selectKiralik()";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                conn.Close();
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 C = new Form10();
            C.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int result = 0;
            if (rowIndex < 0)
            {
                try
                {
                    sql = @"select * from insert_kiralik(:_urunId, :_urunAdi, :_kategori, :_kiraFiyati)";
                    cmd = new Npgsql.NpgsqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("_urunId", int.Parse(textBox1.Text));
                    cmd.Parameters.AddWithValue("_urunAdi", textBox2.Text);
                    cmd.Parameters.AddWithValue("_kategori", textBox3.Text);
                    cmd.Parameters.AddWithValue("_kiraFiyati", int.Parse(textBox4.Text));
                    conn.Open();
                    result = (int)cmd.ExecuteScalar();
                    conn.Close();
                    if (result == 1)
                    {
                        MessageBox.Show("Kaydetme islemi basarili oldu");
                        Select();
                    }
                    else
                    {
                        MessageBox.Show("Kaydetme islemi başarısız oldu");
                    }

                }
                catch (Exception ex)
                {
                    conn.Close();
                    MessageBox.Show("Kaydetme islemi başarısız oldu. Error: " + ex.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (rowIndex < 0)
            {
                MessageBox.Show("Lütfen kullanıcı seçiniz");
                return;
            }
            try
            {
                conn.Open();
                sql = @"select * from update_kiralik(:_kiralikId,:_urunId, :_urunAdi, :_kategori, :_kiraFiyati)";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_kiralikId", int.Parse(dataGridView1.Rows[rowIndex].Cells["k_kiralikId"].Value.ToString()));
                cmd.Parameters.AddWithValue("_urunId", int.Parse(textBox1.Text));
                cmd.Parameters.AddWithValue("_urunAdi", textBox2.Text);
                cmd.Parameters.AddWithValue("_kategori", textBox3.Text);
                cmd.Parameters.AddWithValue("_kiraFiyati", int.Parse(textBox4.Text));
                if ((int)cmd.ExecuteScalar() == 1)
                {
                    sql = @"select * from st_selectKiralik()";
                    cmd = new Npgsql.NpgsqlCommand(sql, conn);
                    dt = new DataTable();
                    dt.Load(cmd.ExecuteReader());
                    conn.Close();
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = dt;
                    MessageBox.Show("Guncelleme işlemi başarılı");
                    rowIndex = -1;

                }
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Update fail. Error: " + ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (rowIndex < 0)
            {
                MessageBox.Show("Lütfen kullanıcı seçiniz");
                return;
            }
            try
            {
                conn.Open();
                sql = @"select * from Kiralik_delete(:k_kiralikId)";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("k_kiralikId", int.Parse(dataGridView1.Rows[rowIndex].Cells["k_kiralikId"].Value.ToString()));
                if ((int)cmd.ExecuteScalar() == 1)
                {
                    sql = @"select * from st_selectKiralik()";
                    cmd = new Npgsql.NpgsqlCommand(sql, conn);
                    dt = new DataTable();
                    dt.Load(cmd.ExecuteReader());
                    conn.Close();
                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = dt;
                    MessageBox.Show("Silme işlemi başarılı");
                    rowIndex = -1;

                }
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Deleted fail. Error: " + ex.Message);
            }
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            Select();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                rowIndex = e.RowIndex;
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["k_urunId"].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["k_urunAdi"].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells["k_kategori"].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells["k_kiraFiyati"].Value.ToString();
            }
        }
    }
}
