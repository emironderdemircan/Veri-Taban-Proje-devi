﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bisiklet
{
    public partial class Form4 : Form
    {

        private string connectionString = "server=localHost; port=5432; Database=bisiklet; user ID=postgres; password=123";
        private Npgsql.NpgsqlConnection conn;
        private string sql;
        private Npgsql.NpgsqlCommand cmd;
        private DataTable dt;
        private int rowIndex = -1;


        public Form4()
        {
            InitializeComponent();
            conn = new Npgsql.NpgsqlConnection(connectionString);
            Select();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            Select();
        }

        void Select()
        {
            try
            {
                conn.Open();
                sql = @"select * from st_select()";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                dt = new DataTable();
                dt.Load(cmd.ExecuteReader());
                conn.Close();
                kullaniciData.DataSource = null;
                kullaniciData.DataSource = dt;
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void kaydetButton_Click(object sender, EventArgs e)
        {
            int result = 0;
            if (rowIndex < 0)
            {
                try
                {
                    sql = @"select * from insert_kullanici(:_ad, :_soyad, :_email, :_yetki, :_cinsiyet)";
                    cmd = new Npgsql.NpgsqlCommand(sql, conn);
                    cmd.Parameters.AddWithValue("_ad", textBox1.Text);
                    cmd.Parameters.AddWithValue("_soyad", textBox2.Text);
                    cmd.Parameters.AddWithValue("_email", textBox3.Text);
                    cmd.Parameters.AddWithValue("_yetki", textBox4.Text);
                    cmd.Parameters.AddWithValue("_cinsiyet", textBox5.Text);

                    conn.Open();
                    result = (int)cmd.ExecuteScalar();
                    conn.Close();
                    if (result == 1)
                    {
                        MessageBox.Show("Kaydetme islemi basarili oldu");
                        Select();
                    }
                    else
                    {
                        MessageBox.Show("Kaydetme islemi başarısız oldu");
                    }

                }
                catch (Exception ex)
                {
                    conn.Close();
                    MessageBox.Show("Kaydetme islemi başarısız oldu. Error: " + ex.Message);
                }
            }                              
        }
        private void guncelleButton_Click_1(object sender, EventArgs e)
        {
            if (rowIndex < 0)
            {
                MessageBox.Show("Lütfen kullanıcı seçiniz");
                return;
            }
            try
            {
                conn.Open();
                sql = @"select * from update_kullanici(:_kullaniciId,:_ad, :_soyad, :_email, :_yetki, :_cinsiyet)";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("_kullaniciId", int.Parse(kullaniciData.Rows[rowIndex].Cells["k_kullaniciId"].Value.ToString()));
                cmd.Parameters.AddWithValue("_ad", textBox1.Text);
                cmd.Parameters.AddWithValue("_soyad", textBox2.Text);
                cmd.Parameters.AddWithValue("_email", textBox3.Text);
                cmd.Parameters.AddWithValue("_yetki", textBox4.Text);
                cmd.Parameters.AddWithValue("_cinsiyet", textBox5.Text);
                if ((int)cmd.ExecuteScalar() == 1)
                {
                    sql = @"select * from st_select()";
                    cmd = new Npgsql.NpgsqlCommand(sql, conn);
                    dt = new DataTable();
                    dt.Load(cmd.ExecuteReader());
                    conn.Close();
                    kullaniciData.DataSource = null;
                    kullaniciData.DataSource = dt;
                    MessageBox.Show("Guncelleme işlemi başarılı");
                    rowIndex = -1;

                }
                conn.Close();
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Update fail. Error: " + ex.Message);
            }
        }
        private void silButton_Click(object sender, EventArgs e)
        {
            if (rowIndex < 0)
            {
                MessageBox.Show("Lütfen kullanıcı seçiniz");
                return;
            }
            try
            {
                conn.Open();
                sql = @"select * from Kullanici_delete(:k_kullaniciId)";
                cmd = new Npgsql.NpgsqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("k_kullaniciId", int.Parse(kullaniciData.Rows[rowIndex].Cells["k_kullaniciId"].Value.ToString()));
                if ((int)cmd.ExecuteScalar() == 1)
                {
                    sql = @"select * from st_select()";
                    cmd = new Npgsql.NpgsqlCommand(sql, conn);
                    dt = new DataTable();
                    dt.Load(cmd.ExecuteReader());
                    conn.Close();
                    kullaniciData.DataSource = null;
                    kullaniciData.DataSource = dt;
                    MessageBox.Show("Silme işlemi başarılı");
                    rowIndex = -1;
                    
                }
                conn.Close();              
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show("Deleted fail. Error: " + ex.Message);              
            }
        }
        private void kullaniciData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                rowIndex = e.RowIndex;
                textBox1.Text = kullaniciData.Rows[e.RowIndex].Cells["k_ad"].Value.ToString();
                textBox2.Text = kullaniciData.Rows[e.RowIndex].Cells["k_soyad"].Value.ToString();
                textBox3.Text = kullaniciData.Rows[e.RowIndex].Cells["k_email"].Value.ToString();
                textBox4.Text = kullaniciData.Rows[e.RowIndex].Cells["k_yetki"].Value.ToString();
                textBox5.Text = kullaniciData.Rows[e.RowIndex].Cells["k_cinsiyet"].Value.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 A = new Form1();
            A.Show();
        }
    }
}
